import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ApiServiceService {
  constructor(private http:HttpClient) { }
  getCusips() {
   return this.http.get("http://localhost:8080/cusips?portfolioGroupName=A_CCLGSCPL&UserName=anjindal" );
  }
}
