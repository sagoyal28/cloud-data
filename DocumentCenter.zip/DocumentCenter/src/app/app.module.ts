import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ServiceComponent } from './components/service/service.component';
import { SideBarComponent } from './components/service/side-bar/side-bar.component';
import { GridDisplayComponent } from './components/service/grid-display/grid-display.component';
import { SearchBarComponent } from './components/service/search-bar/search-bar.component';
import { ApiServiceService } from "./services/api-service.service";

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    ServiceComponent,
    SideBarComponent,
    GridDisplayComponent,
    SearchBarComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule
  ],
  providers: [ApiServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
