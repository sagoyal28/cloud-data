import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { ApiServiceService } from "../../../services/api-service.service";

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})
export class SideBarComponent {
   @Output() valueChange = new EventEmitter();
  cusipsData;
  constructor(private cusip: ApiServiceService) {}
 getDistinctCusips() {
    this.cusip.getCusips().subscribe(
      res => {
        this.cusipsData = res;
        this.valueChange.emit(this.cusipsData);
        console.log("res is ", res);
      });
  }
}

